import { CatalogScreen } from "../src/screens/CatalogScreen";
export default function LiveScreen() { return <CatalogScreen section="live" />; }
