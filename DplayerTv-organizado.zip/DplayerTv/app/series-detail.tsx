export { default } from "../src/screens/SeriesDetailScreen";
