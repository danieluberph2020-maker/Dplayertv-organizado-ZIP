import { CatalogScreen } from "../src/screens/CatalogScreen";
export default function SeriesScreen() { return <CatalogScreen section="series" />; }
