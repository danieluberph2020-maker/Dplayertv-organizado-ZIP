import { CatalogScreen } from "../src/screens/CatalogScreen";
export default function MoviesScreen() { return <CatalogScreen section="movie" />; }
