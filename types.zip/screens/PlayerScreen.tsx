import { useEffect, useState } from "react";
import { ActivityIndicator, Pressable, Text, View } from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { VideoView, useVideoPlayer } from "expo-video";
import { colors } from "../theme";

export default function PlayerScreen() {
  const params = useLocalSearchParams<{ url?: string; title?: string; kind?: string }>();
  const url = typeof params.url === "string" ? params.url : "";
  const title = typeof params.title === "string" ? params.title : "Reproduzindo";
  const [rate, setRate] = useState(1);
  const [error, setError] = useState("");
  const player = useVideoPlayer(url ? { uri: url } : null, instance => {
    instance.loop = false;
    instance.play();
  });
  useEffect(() => {
    if (!url) setError("Endereço de reprodução não informado.");
    return () => { player.pause(); };
  }, [url, player]);
  function changeRate() {
    const next = rate >= 5 ? 1 : rate + 1;
    setRate(next);
    player.playbackRate = next;
    if (!player.playing) player.play();
  }
  function togglePlayback() {
    if (player.playing) { player.pause(); setRate(1); player.playbackRate = 1; }
    else player.play();
  }
  return <View style={{ flex: 1, backgroundColor: "#000000", padding: 18, paddingTop: 26 }}>
    <Pressable onPress={() => router.back()} style={{ padding: 10, alignSelf: "flex-start" }}><Text style={{ color: colors.blue, fontWeight: "800" }}>‹  VOLTAR</Text></Pressable>
    <Text numberOfLines={1} style={{ color: colors.text, fontSize: 18, fontWeight: "700", marginVertical: 10 }}>{title}</Text>
    <View style={{ flex: 1, justifyContent: "center" }}>
      {url ? <VideoView player={player} style={{ width: "100%", aspectRatio: 16 / 9, backgroundColor: "#000000" }} nativeControls contentFit="contain" allowsPictureInPicture /> : <ActivityIndicator color={colors.blue} />}
      {!!error && <Text style={{ color: colors.danger, marginTop: 12 }}>{error}</Text>}
    </View>
    <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 18, paddingVertical: 18 }}>
      <Pressable onPress={changeRate} style={{ padding: 14, borderRadius: 10, backgroundColor: colors.surface }}><Text style={{ color: colors.text, fontWeight: "800" }}>Avançar {rate}x</Text></Pressable>
      <Pressable onPress={togglePlayback} style={{ padding: 14, borderRadius: 10, backgroundColor: colors.blue }}><Text style={{ color: "#FFFFFF", fontWeight: "800" }}>{player.playing ? "Pausar" : "Reproduzir"}</Text></Pressable>
      <Pressable onPress={() => {setRate(1);player.playbackRate=1;player.replay();}} style={{ padding: 14, borderRadius: 10, backgroundColor: colors.surface }}><Text style={{ color: colors.text, fontWeight: "800" }}>Reiniciar</Text></Pressable>
    </View>
    <Text style={{ color: colors.muted, textAlign: "center", fontSize: 11 }}>A velocidade depende do formato e do suporte do fluxo de vídeo.</Text>
  </View>;
}
