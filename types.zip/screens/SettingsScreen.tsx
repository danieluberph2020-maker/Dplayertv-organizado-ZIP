import { Pressable, Text, View } from "react-native";
import { router } from "expo-router";
import { SectionScreen, sectionStyles as s } from "../components/SectionScreen";
import { colors } from "../theme";
export default function SettingsScreen() {
  return <SectionScreen title="Configurações" subtitle="Gerencie o aplicativo e suas listas">
    <Pressable onPress={() => router.push("/lists")} style={[s.panel, { borderColor: colors.blue }]}>
      <Text style={s.panelTitle}>Gerenciar listas</Text><Text style={s.body}>Visualizar, adicionar, alternar ou remover listas.</Text><Text style={s.action}>ABRIR  ›</Text>
    </Pressable>
    <Pressable onPress={() => router.push("/account")} style={s.panel}>
      <Text style={s.panelTitle}>Conta</Text><Text style={s.body}>Usuário, situação e validade informados pelo provedor.</Text><Text style={s.action}>VER CONTA  ›</Text>
    </Pressable>
    {["Reprodução", "Áudio e legendas", "Aparência", "Idioma", "Sobre"].map(item =>
      <View key={item} style={s.panel}><Text style={s.panelTitle}>{item}</Text><Text style={s.body}>Configuração será implementada nas próximas etapas.</Text></View>
    )}
    <Text style={{ color: colors.muted, fontSize: 12 }}>A sessão do provedor é mantida localmente. Sair do aplicativo não remove listas ou preferências.</Text>
  </SectionScreen>;
}