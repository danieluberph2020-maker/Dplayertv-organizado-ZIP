import { useCallback, useState } from "react";
import { Alert, Pressable, Text, View } from "react-native";
import { useFocusEffect, router } from "expo-router";
import { SectionScreen, sectionStyles as s } from "../components/SectionScreen";
import { colors } from "../theme";
import { getActivePlaylistId, getPlaylists, removePlaylist, setActivePlaylist } from "../storage/playlists";
import { removeCachedCatalog } from "../storage/catalogCache";
import type { SavedPlaylist } from "../types/media";

export default function ListsScreen() {
  const [items, setItems] = useState<SavedPlaylist[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const refresh = useCallback(async () => {
    const [saved, current] = await Promise.all([getPlaylists(), getActivePlaylistId()]);
    setItems(saved); setActive(current);
  }, []);
  useFocusEffect(useCallback(() => { refresh(); }, [refresh]));
  function confirmDelete(item: SavedPlaylist) {
    Alert.alert("Excluir lista?", "A lista " + item.name + " será removida deste dispositivo. Isso não altera sua conta no provedor.", [
      { text: "Cancelar", style: "cancel" },
      { text: "Excluir", style: "destructive", onPress: async () => { await removePlaylist(item.id); await removeCachedCatalog(item.id); await refresh(); } }
    ]);
  }
  return <SectionScreen title="Gerenciar listas" subtitle="Adicione, alterne ou remova suas fontes">
    <Pressable onPress={() => router.push("/connect")} style={[s.panel, { borderColor: colors.blue }]}>
      <Text style={s.panelTitle}>＋ Adicionar nova lista</Text><Text style={s.body}>Xtream Codes ou endereço M3U/M3U8.</Text>
    </Pressable>
    {items.length === 0 ? <View style={s.panel}><Text style={s.body}>Nenhuma lista salva neste dispositivo.</Text></View> : items.map(item =>
      <View key={item.id} style={s.panel}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
          <Text style={s.panelTitle}>{item.name}</Text>
          {active === item.id ? <Text style={{ color: colors.success, fontSize: 11, fontWeight: "800" }}>ATIVA</Text> : null}
        </View>
        <Text style={s.body}>{item.kind === "xtream" ? "Xtream Codes" : item.kind === "m3u-file" ? "Arquivo M3U" : "URL M3U"}</Text>
        {active !== item.id ? <Pressable onPress={async () => { await setActivePlaylist(item.id); setActive(item.id); }}><Text style={s.action}>USAR ESTA LISTA</Text></Pressable> : null}
        <Pressable onPress={() => confirmDelete(item)}><Text style={{ color: colors.danger, fontWeight: "700", marginTop: 12 }}>EXCLUIR LISTA</Text></Pressable>
      </View>
    )}
    <Text style={s.body}>Trocar a lista ativa não apaga as demais. A exclusão remove somente os dados locais desta lista.</Text>
  </SectionScreen>;
}