import { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, FlatList, Image, Pressable, Text, TextInput, View } from "react-native";
import { SectionScreen, sectionStyles as s } from "../components/SectionScreen";
import { router } from "expo-router";
import { colors } from "../theme";
import { getActivePlaylist } from "../storage/playlists";
import { loadCatalog } from "../services/catalog";
import { cacheCatalog, getCachedCatalog } from "../storage/catalogCache";
import { getFavoriteIds, toggleFavorite } from "../storage/favorites";
import type { Catalog, MediaItem, SavedPlaylist } from "../types/media";

type Section = "live" | "movie" | "series";
const labels = { live: "TV ao vivo", movie: "Filmes", series: "Séries" };
export function CatalogScreen({ section }: { section: Section }) {
  const [playlist, setPlaylist] = useState<SavedPlaylist | null>(null);
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [filter, setFilter] = useState("Todos");
  const [search, setSearch] = useState("");
  const [onlyFavorites, setOnlyFavorites] = useState(false);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState("");
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const selected = await getActivePlaylist();
        if (!alive) return;
        setPlaylist(selected);
        if (!selected) { setError("Adicione uma lista em Configurações para carregar seu conteúdo."); setBusy(false); return; }
        const cached = await getCachedCatalog(selected.id);
        if (cached && alive) { setCatalog(cached); setBusy(false); }
        const loaded = await loadCatalog(selected);
        await cacheCatalog(selected.id, loaded);
        if (alive) { setCatalog(loaded); setError(""); setBusy(false); }
      } catch (e) {
        if (alive) { setError(e instanceof Error ? e.message : "Não foi possível carregar o catálogo."); setBusy(false); }
      }
    })();
    return () => { alive = false; };
  }, []);
  useEffect(() => {
    if (playlist) getFavoriteIds(playlist.id, section).then(setFavorites);
  }, [playlist, section]);
  const source = catalog ? (section === "live" ? catalog.live : section === "movie" ? catalog.movies : catalog.series) : [];
  const categories = useMemo(() => ["Todos", ...Array.from(new Set(source.map(x => x.group))).sort((a,b)=>a.localeCompare(b))], [source]);
  const filtered = useMemo(() => source.filter(x =>
    (!onlyFavorites || favorites.includes(x.id)) &&
    (filter === "Todos" || x.group === filter) &&
    x.title.toLocaleLowerCase().includes(search.toLocaleLowerCase())
  ), [source, onlyFavorites, favorites, filter, search]);
  async function favorite(item: MediaItem) {
    if (!playlist) return;
    const now = await toggleFavorite({ playlistId: playlist.id, section, mediaId: item.id });
    setFavorites(old => now ? [...old, item.id] : old.filter(id => id !== item.id));
  }
  return <SectionScreen title={labels[section]} subtitle={playlist ? "Lista: " + playlist.name : "Seu catálogo"}>
    <View style={{ gap: 10 }}>
      <TextInput value={search} onChangeText={setSearch} placeholder="Buscar título ou canal" placeholderTextColor={colors.muted} style={{ color: colors.text, backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 10, padding: 12 }} />
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 7 }}>
        <Pressable onPress={() => setOnlyFavorites(false)} style={{ backgroundColor: !onlyFavorites ? colors.blueSoft : colors.surface, padding: 9, borderRadius: 8 }}><Text style={{ color: colors.text }}>Todos</Text></Pressable>
        <Pressable onPress={() => setOnlyFavorites(true)} style={{ backgroundColor: onlyFavorites ? colors.blueSoft : colors.surface, padding: 9, borderRadius: 8 }}><Text style={{ color: colors.text }}>♥ Favoritos</Text></Pressable>
        {categories.slice(1).map(c => <Pressable key={c} onPress={() => {setFilter(c);setOnlyFavorites(false);}} style={{ backgroundColor: filter === c ? colors.blueSoft : colors.surface, padding: 9, borderRadius: 8 }}><Text style={{ color: colors.text }}>{c}</Text></Pressable>)}
      </View>
    </View>
    {busy && !catalog ? <ActivityIndicator color={colors.blue} /> : null}
    {!!error ? <View style={s.panel}><Text style={s.body}>{error}</Text></View> : null}
    {catalog && source.length === 0 ? <View style={s.panel}><Text style={s.body}>{section === "live" ? "Nenhum canal encontrado." : playlist?.kind === "m3u" || playlist?.kind === "m3u-file" ? "Esta lista M3U não fornece catálogo de filmes ou séries identificado. Para essas seções, use uma conexão Xtream compatível." : "Nenhum conteúdo encontrado nesta seção."}</Text></View> : null}
    <FlatList data={filtered} keyExtractor={x => x.id} initialNumToRender={16} windowSize={7} contentContainerStyle={{ gap: 8, paddingBottom: 32 }} renderItem={({item}) =>
      <View style={{ flexDirection: "row", alignItems: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, borderRadius: 10, padding: 10, gap: 12 }}>
        <Pressable onPress={() => item.kind === "series" && item.isSeriesContainer ? router.push({ pathname: "/series-detail", params: { id: item.id, title: item.title } }) : router.push({ pathname: "/player", params: { url: item.url, title: item.title, kind: item.kind } })} style={{ flex: 1, flexDirection: "row", alignItems: "center", gap: 12 }}>
          {item.logo || item.poster ? <Image source={{ uri: item.logo || item.poster }} style={{ width: 54, height: 64, borderRadius: 6, backgroundColor: colors.surfaceRaised }} resizeMode="cover" /> : <View style={{ width: 54, height: 64, borderRadius: 6, backgroundColor: colors.surfaceRaised, alignItems: "center", justifyContent: "center" }}><Text style={{ color: colors.blue }}>▶</Text></View>}
          <View style={{ flex: 1 }}><Text style={s.panelTitle} numberOfLines={2}>{item.title}</Text><Text style={s.body}>{item.group}</Text><Text style={{ color: colors.blue, fontSize: 11, marginTop: 4 }}>REPRODUZIR</Text></View>
        </Pressable>
        <Pressable onPress={() => favorite(item)}><Text style={{ color: favorites.includes(item.id) ? colors.blue : colors.muted, fontSize: 22 }}>♥</Text></Pressable>
      </View>
    } ListEmptyComponent={catalog && source.length ? <Text style={s.body}>Nenhum resultado para esse filtro.</Text> : null} />
    {busy && catalog ? <Text style={s.body}>Atualizando catálogo em segundo plano…</Text> : null}
  </SectionScreen>;
}