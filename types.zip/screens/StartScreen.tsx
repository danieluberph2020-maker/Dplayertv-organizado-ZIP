import { useCallback, useState } from "react";
import { ScrollView, StyleSheet, Text, View } from "react-native";
import { useFocusEffect } from "expo-router";
import { colors } from "../theme";
import { getActivePlaylist } from "../storage/playlists";
import { BrandHeader } from "../components/BrandHeader";
import { LoginForm } from "../components/LoginForm";
import HomeScreen from "./HomeScreen";

type Gate = "loading" | "login" | "home";

export default function StartScreen() {
  const [gate, setGate] = useState<Gate>("loading");
  useFocusEffect(useCallback(() => {
    let alive = true;
    getActivePlaylist()
      .then(list => { if (alive) setGate(list ? "home" : "login"); })
      .catch(() => { if (alive) setGate("login"); });
    return () => { alive = false; };
  }, []));

  if (gate === "loading") return <View style={styles.blank} />;
  if (gate === "home") return <HomeScreen />;
  return (
    <ScrollView style={styles.blank} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
      <BrandHeader />
      <View style={styles.welcome}>
        <Text style={styles.eyebrow}>BEM-VINDO</Text>
        <Text style={styles.heading}>Entrar</Text>
        <Text style={styles.description}>Conecte sua lista para começar.</Text>
      </View>
      <LoginForm onSuccess={() => setGate("home")} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  blank: { flex: 1, backgroundColor: colors.background },
  content: { padding: 28, paddingTop: 44, paddingBottom: 40 },
  welcome: { marginTop: 36, marginBottom: 22 },
  eyebrow: { color: colors.blue, fontSize: 11, fontWeight: "800", letterSpacing: 2 },
  heading: { color: colors.text, fontSize: 30, fontWeight: "800", marginTop: 8 },
  description: { color: colors.muted, fontSize: 14, marginTop: 7 },
});
