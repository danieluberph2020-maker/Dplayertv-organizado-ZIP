import { useEffect, useState } from "react";
import { ActivityIndicator, Image, Pressable, Text, View } from "react-native";
import { useLocalSearchParams, router } from "expo-router";
import { SectionScreen, sectionStyles as s } from "../components/SectionScreen";
import { colors } from "../theme";
import { getActivePlaylist, getXtreamPassword } from "../storage/playlists";
import { getSeriesDetails } from "../api/xtream";
import type { SeriesDetails } from "../types/media";

export default function SeriesDetailScreen() {
  const params = useLocalSearchParams<{ id?: string; title?: string }>();
  const id = typeof params.id === "string" ? params.id : "";
  const title = typeof params.title === "string" ? params.title : "Série";
  const [details, setDetails] = useState<SeriesDetails | null>(null);
  const [season, setSeason] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(true);
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const list = await getActivePlaylist();
        if (!list || list.kind !== "xtream" || !list.serverUrl || !list.username) throw new Error("Detalhes de episódios exigem uma lista Xtream compatível.");
        const password = await getXtreamPassword(list.id);
        if (!password) throw new Error("Senha não encontrada. Adicione novamente esta lista.");
        const result = await getSeriesDetails({ serverUrl: list.serverUrl, username: list.username, password }, id);
        if (alive) { setDetails(result); setSeason(result.seasons[0]?.season || ""); }
      } catch (e) { if (alive) setError(e instanceof Error ? e.message : "Não foi possível carregar os episódios."); }
      finally { if (alive) setBusy(false); }
    })();
    return () => { alive = false; };
  }, [id]);
  const selected = details?.seasons.find(x => x.season === season);
  return <SectionScreen title={details?.title || title} subtitle="Temporadas e episódios">
    {details?.poster ? <Image source={{ uri: details.poster }} style={{ width: 130, height: 180, borderRadius: 9 }} resizeMode="cover" /> : null}
    {!!details?.plot && <Text style={s.body}>{details.plot}</Text>}
    {busy ? <ActivityIndicator color={colors.blue} /> : null}
    {!!error && <View style={s.panel}><Text style={s.body}>{error}</Text></View>}
    {details && <>
      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
        {details.seasons.map(x => <Pressable key={x.season} onPress={() => setSeason(x.season)} style={{ padding: 10, borderRadius: 8, backgroundColor: season === x.season ? colors.blueSoft : colors.surface }}><Text style={{ color: colors.text }}>Temporada {x.season}</Text></Pressable>)}
      </View>
      {(selected?.episodes || []).map(ep => <Pressable key={ep.id} onPress={() => router.push({ pathname: "/player", params: { url: ep.url, title: ep.title, kind: "series" } })} style={s.panel}>
        <Text style={s.panelTitle}>E{ep.episode} — {ep.title}</Text>
        {!!ep.plot && <Text style={s.body}>{ep.plot}</Text>}
        <Text style={s.action}>▶ REPRODUZIR</Text>
      </Pressable>)}
      {details.seasons.length === 0 ? <Text style={s.body}>O provedor não retornou episódios para esta série.</Text> : null}
    </>}
  </SectionScreen>;
}