import { useState } from "react";
import { router } from "expo-router";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { colors } from "../theme";
import { BrandHeader } from "../components/BrandHeader";

const sections = [
  { title: "TV ao vivo", subtitle: "Seus canais", icon: "LIVE", route: "/live" as const },
  { title: "Filmes", subtitle: "Sua biblioteca", icon: "FILM", route: "/movies" as const },
  { title: "Séries", subtitle: "Temporadas e episódios", icon: "SERIES", route: "/series" as const },
  { title: "Configurações", subtitle: "Listas e preferências", icon: "SET", route: "/settings" as const },
];

export default function HomeScreen() {
  const [focusedCard, setFocusedCard] = useState<string | null>(null);

  return (
    <View style={styles.screen}>
      <BrandHeader />

      <View style={styles.welcome}>
        <Text style={styles.eyebrow}>BEM-VINDO</Text>
        <Text style={styles.heading}>O que vamos assistir?</Text>
        <Text style={styles.description}>Escolha uma seção para começar.</Text>
      </View>

      <View style={styles.grid}>
        {sections.map((item) => (
          <Pressable
            key={item.title}
            accessibilityRole="button"
            onPress={() => router.push(item.route)}
            onFocus={() => setFocusedCard(item.title)}
            onBlur={() => setFocusedCard(null)}
            style={({ pressed }) => [
              styles.card,
              (focusedCard === item.title || pressed) && styles.cardActive,
            ]}
          >
            <View style={styles.icon}><Text style={styles.iconText}>{item.icon}</Text></View>
            <Text style={styles.cardTitle}>{item.title}</Text>
            <Text style={styles.cardSubtitle}>{item.subtitle}</Text>
            <Text style={styles.arrow}>›</Text>
          </Pressable>
        ))}
      </View>
      <Text style={styles.footer}>DplayerTv • Reprodutor de mídia</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background, paddingHorizontal: 28, paddingTop: 30, paddingBottom: 18 },
  welcome: { marginTop: 52, marginBottom: 26 },
  eyebrow: { color: colors.blue, fontSize: 11, fontWeight: "800", letterSpacing: 2 },
  heading: { color: colors.text, fontSize: 30, fontWeight: "800", marginTop: 8 },
  description: { color: colors.muted, fontSize: 14, marginTop: 7 },
  grid: { flexDirection: "row", flexWrap: "wrap", gap: 14 },
  card: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 16, minHeight: 154, flexGrow: 1, flexBasis: "46%", padding: 18, justifyContent: "center" },
  cardActive: { borderColor: colors.blue, backgroundColor: "#101D30" },
  icon: { width: 38, height: 30, borderRadius: 8, backgroundColor: colors.blueSoft, alignItems: "center", justifyContent: "center", marginBottom: 16 },
  iconText: { color: colors.blue, fontSize: 9, fontWeight: "900", letterSpacing: 0.5 },
  cardTitle: { color: colors.text, fontSize: 18, fontWeight: "700" },
  cardSubtitle: { color: colors.muted, fontSize: 12, marginTop: 5 },
  arrow: { position: "absolute", right: 17, top: 16, color: colors.blue, fontSize: 26 },
  footer: { color: "#596273", fontSize: 10, textAlign: "center", marginTop: "auto", paddingTop: 20 }
});
