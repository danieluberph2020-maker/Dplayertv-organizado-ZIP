import { useEffect, useState } from "react";
import { ActivityIndicator, Text, View } from "react-native";
import { SectionScreen, sectionStyles as s } from "../components/SectionScreen";
import { colors } from "../theme";
import { getActivePlaylist, getXtreamPassword } from "../storage/playlists";
import { getAccountInfo } from "../api/xtream";

function expirationLabel(value?: string | null) {
  if (!value || value === "0") return "Não informado pelo provedor";
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return "Não informado pelo provedor";
  const date = new Date(numeric * 1000);
  if (Number.isNaN(date.getTime())) return "Não informado pelo provedor";
  return date.toLocaleString("pt-BR");
}
export default function AccountScreen() {
  const [data, setData] = useState<{ name: string; username: string; status: string; expiry: string } | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(true);
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const list = await getActivePlaylist();
        if (!list) throw new Error("Nenhuma lista ativa.");
        if (list.kind !== "xtream" || !list.serverUrl || !list.username) {
          if (alive) setData({ name: list.name, username: "Não disponível para M3U", status: "Informação não fornecida", expiry: "Não disponível para M3U" });
          return;
        }
        const password = await getXtreamPassword(list.id);
        if (!password) throw new Error("Senha não encontrada no armazenamento seguro.");
        const account = await getAccountInfo({ serverUrl: list.serverUrl, username: list.username, password });
        const info = account.user_info;
        if (alive) setData({ name: list.name, username: info?.username || list.username, status: info?.status || "Não informado", expiry: expirationLabel(info?.exp_date) });
      } catch (e) { if (alive) setError(e instanceof Error ? e.message : "Não foi possível consultar a conta."); }
      finally { if (alive) setBusy(false); }
    })();
    return () => { alive = false; };
  }, []);
  return <SectionScreen title="Conta" subtitle="Informações fornecidas pela sua lista ativa">
    {busy ? <ActivityIndicator color={colors.blue} /> : null}
    {!!error && <View style={s.panel}><Text style={s.body}>{error}</Text></View>}
    {data && <View style={s.panel}>
      <Text style={s.panelTitle}>{data.name}</Text>
      <Text style={s.body}>Usuário: {data.username}</Text>
      <Text style={s.body}>Situação: {data.status}</Text>
      <Text style={s.body}>Validade: {data.expiry}</Text>
    </View>}
    <Text style={s.body}>A disponibilidade e a precisão dessas informações dependem do provedor. O DplayerTv não altera nem renova a assinatura.</Text>
  </SectionScreen>;
}