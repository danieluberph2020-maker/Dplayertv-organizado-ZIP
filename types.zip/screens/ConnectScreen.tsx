import { Text } from "react-native";
import { router } from "expo-router";
import { SectionScreen, sectionStyles as s } from "../components/SectionScreen";
import { LoginForm } from "../components/LoginForm";

export default function ConnectScreen() {
  return (
    <SectionScreen title="Adicionar lista" subtitle="Conecte outra fonte de conteúdo autorizada">
      <LoginForm showName submitLabel="Adicionar" onSuccess={() => router.replace("/")} />
      <Text style={s.body}>As listas são armazenadas neste dispositivo. A senha é protegida pelo armazenamento seguro do sistema.</Text>
    </SectionScreen>
  );
}
