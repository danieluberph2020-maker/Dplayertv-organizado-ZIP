import { StyleSheet, Text, View } from "react-native";
import { colors } from "../theme";

export function BrandHeader() {
  return (
    <View style={styles.header}>
      <View style={styles.brandMark}><Text style={styles.brandMarkText}>D</Text></View>
      <View>
        <Text style={styles.brand}>Dplayer<Text style={styles.brandAccent}>Tv</Text></Text>
        <Text style={styles.tagline}>SEU CONTEÚDO, EM UM SÓ LUGAR</Text>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  header: { flexDirection: "row", alignItems: "center", gap: 12 },
  brandMark: { width: 42, height: 42, borderRadius: 12, backgroundColor: colors.blue, alignItems: "center", justifyContent: "center" },
  brandMarkText: { color: "#FFFFFF", fontSize: 26, fontWeight: "900" },
  brand: { color: colors.text, fontSize: 22, fontWeight: "800", letterSpacing: 0.2 },
  brandAccent: { color: colors.blue },
  tagline: { color: colors.muted, fontSize: 8, letterSpacing: 1.6, marginTop: 2 },
});
