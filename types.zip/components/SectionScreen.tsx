import { ReactNode } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { router } from "expo-router";
import { colors } from "../theme";

type Props = { title: string; subtitle: string; children?: ReactNode };
export function SectionScreen({ title, subtitle, children }: Props) {
  return (
    <View style={styles.screen}>
      <Pressable onPress={() => router.replace("/")} style={styles.back} accessibilityRole="button">
        <Text style={styles.backText}>‹  INÍCIO</Text>
      </Pressable>
      <Text style={styles.eyebrow}>DPLAYERTV</Text>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.subtitle}>{subtitle}</Text>
      <View style={styles.content}>{children}</View>
    </View>
  );
}
export const sectionStyles = StyleSheet.create({
  panel: { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1, borderRadius: 14, padding: 18, gap: 8 },
  panelTitle: { color: colors.text, fontSize: 16, fontWeight: "700" },
  body: { color: colors.muted, fontSize: 13, lineHeight: 20 },
  action: { color: colors.blue, fontWeight: "700", marginTop: 8 }
});
const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: colors.background, padding: 26, paddingTop: 34 },
  back: { alignSelf: "flex-start", paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8 },
  backText: { color: colors.blue, fontSize: 13, fontWeight: "800" },
  eyebrow: { color: colors.blue, fontSize: 10, letterSpacing: 2, fontWeight: "800", marginTop: 32 },
  title: { color: colors.text, fontSize: 30, fontWeight: "800", marginTop: 8 },
  subtitle: { color: colors.muted, fontSize: 14, marginTop: 6 },
  content: { marginTop: 28, gap: 14 }
});