import { useState } from "react";
import { ActivityIndicator, Pressable, Text, TextInput, View } from "react-native";
import { colors } from "../theme";
import { sectionStyles as s } from "./SectionScreen";
import { addPlaylist, type NewPlaylistInput } from "../services/addPlaylist";

type Mode = "xtream" | "link";
type Props = { onSuccess: () => void; showName?: boolean; submitLabel?: string };

export function LoginForm({ onSuccess, showName = false, submitLabel = "Entrar" }: Props) {
  const [mode, setMode] = useState<Mode>("xtream");
  const [name, setName] = useState("");
  const [server, setServer] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [link, setLink] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [isError, setIsError] = useState(false);
  const field = { color: colors.text, backgroundColor: colors.surfaceRaised, borderColor: colors.border, borderWidth: 1, borderRadius: 9, padding: 13, marginTop: 10 } as const;

  function progress(text: string) { setIsError(false); setMessage(text); }
  function fail(text: string) { setIsError(true); setMessage(text); }

  async function submit() {
    if (busy) return;
    setBusy(true); progress("Conectando…");
    try {
      const input: NewPlaylistInput = mode === "xtream"
        ? { mode: "xtream", name, server, username, password }
        : { mode: "m3u", name, url: link };
      await addPlaylist(input, progress);
      onSuccess();
    } catch (error) {
      fail(error instanceof Error ? error.message : "Não foi possível conectar.");
    } finally { setBusy(false); }
  }

  const tab = (value: Mode, label: string) => (
    <Pressable
      accessibilityRole="button"
      onPress={() => { setMode(value); setMessage(""); }}
      style={{ flex: 1, padding: 12, borderRadius: 8, borderWidth: 1, borderColor: mode === value ? colors.blue : "transparent", backgroundColor: mode === value ? colors.blueSoft : colors.surfaceRaised }}
    >
      <Text style={{ color: colors.text, textAlign: "center", fontSize: 13, fontWeight: mode === value ? "700" : "400" }}>{label}</Text>
    </Pressable>
  );

  return (
    <View style={s.panel}>
      {showName ? <TextInput value={name} onChangeText={setName} placeholder="Nome para identificar esta lista (opcional)" placeholderTextColor={colors.muted} style={field} /> : null}
      <View style={{ flexDirection: "row", gap: 7, marginTop: showName ? 10 : 0 }}>
        {tab("xtream", "Usuário e senha")}
        {tab("link", "Somente link")}
      </View>

      {mode === "xtream" ? <>
        <TextInput value={server} onChangeText={setServer} placeholder="Link do servidor (http://...)" placeholderTextColor={colors.muted} autoCapitalize="none" autoCorrect={false} keyboardType="url" style={field} />
        <TextInput value={username} onChangeText={setUsername} placeholder="Usuário" placeholderTextColor={colors.muted} autoCapitalize="none" autoCorrect={false} style={field} />
        <View style={[field, { flexDirection: "row", alignItems: "center", padding: 0 }]}>
          <TextInput
            value={password} onChangeText={setPassword} placeholder="Senha" placeholderTextColor={colors.muted}
            secureTextEntry={!showPassword} autoCapitalize="none" autoCorrect={false}
            returnKeyType="go" onSubmitEditing={submit}
            style={{ flex: 1, color: colors.text, padding: 13 }}
          />
          <Pressable
            onPress={() => setShowPassword(v => !v)} hitSlop={8} accessibilityRole="button"
            accessibilityLabel={showPassword ? "Ocultar senha" : "Mostrar senha"}
            style={{ paddingHorizontal: 14, paddingVertical: 10 }}
          >
            <Text style={{ fontSize: 20, textDecorationLine: showPassword ? "none" : "line-through" }}>👁</Text>
          </Pressable>
        </View>
      </> : (
        <TextInput
          value={link} onChangeText={setLink} placeholder="Cole o link da lista (M3U/M3U8)" placeholderTextColor={colors.muted}
          autoCapitalize="none" autoCorrect={false} keyboardType="url" returnKeyType="go" onSubmitEditing={submit} style={field}
        />
      )}

      <Pressable disabled={busy} onPress={submit} accessibilityRole="button" style={{ backgroundColor: busy ? "#24466D" : colors.blue, borderRadius: 9, padding: 15, alignItems: "center", marginTop: 16 }}>
        {busy ? <ActivityIndicator color="#FFFFFF" /> : <Text style={{ color: "#FFFFFF", fontWeight: "800", fontSize: 15 }}>{submitLabel}</Text>}
      </Pressable>
      {!!message && <Text style={[s.body, isError && { color: colors.danger }]}>{message}</Text>}
    </View>
  );
}
