import * as FileSystem from "expo-file-system/legacy";
import type { Catalog, SavedPlaylist } from "../types/media";
import { getXtreamPassword } from "../storage/playlists";
import { connectXtream } from "../api/xtream";
import { parseM3U } from "../parsers/m3u";

export type { Catalog };
export async function loadCatalog(playlist: SavedPlaylist): Promise<Catalog> {
  if (playlist.kind === "xtream") {
    const password = await getXtreamPassword(playlist.id);
    if (!password || !playlist.serverUrl || !playlist.username) throw new Error("Dados de acesso não encontrados. Edite ou adicione novamente esta lista.");
    const data = await connectXtream({ serverUrl: playlist.serverUrl, username: playlist.username, password });
    return { live: data.live, movies: data.movies, series: data.series, updatedAt: Date.now() };
  }
  if (!playlist.playlistUrl) throw new Error("Endereço da lista não encontrado.");
  let body: string;
  if (playlist.kind === "m3u-file") body = await FileSystem.readAsStringAsync(playlist.playlistUrl);
  else {
    const response = await fetch(playlist.playlistUrl);
    if (!response.ok) throw new Error("Falha ao atualizar M3U (HTTP " + response.status + ").");
    body = await response.text();
  }
  const parsed = parseM3U(body);
  return {
    live: parsed.items.filter(x => x.kind === "live"),
    movies: parsed.items.filter(x => x.kind === "movie"),
    series: parsed.items.filter(x => x.kind === "series"),
    updatedAt: Date.now(),
  };
}
