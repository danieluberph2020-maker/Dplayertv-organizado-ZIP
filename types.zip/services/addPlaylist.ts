import { validateXtream, validateM3UUrl, inspectM3UText } from "./playlistValidation";
import { getAccountInfo } from "../api/xtream";
import { detectXtreamFromM3U } from "../parsers/m3u";
import { addAndActivatePlaylist, createPlaylistId } from "../storage/playlists";
import type { SavedPlaylist, XtreamCredentials } from "../types/media";

export type NewPlaylistInput =
  | { mode: "xtream"; name: string; server: string; username: string; password: string }
  | { mode: "m3u"; name: string; url: string };

async function saveXtream(id: string, name: string, credentials: XtreamCredentials, now: number) {
  const item: SavedPlaylist = { id, name, kind: "xtream", serverUrl: credentials.serverUrl, username: credentials.username, addedAt: now, lastUpdatedAt: now };
  await addAndActivatePlaylist(item, credentials.password);
}

/** Valida a fonte, salva e ativa a lista. `onStatus` recebe mensagens de progresso para a UI. */
export async function addPlaylist(input: NewPlaylistInput, onStatus: (message: string) => void): Promise<void> {
  const id = createPlaylistId();
  const now = Date.now();
  const typedName = input.name.trim();

  if (input.mode === "xtream") {
    const credentials = validateXtream(input.server, input.username, input.password);
    onStatus("Conectando ao servidor…");
    await getAccountInfo(credentials);
    await saveXtream(id, typedName || "Minha lista", credentials, now);
    return;
  }

  const url = validateM3UUrl(input.url);

  // Links do tipo ".../get.php?username=...&password=..." trazem o login dentro deles:
  // nesse caso entramos pelo Xtream, que também libera filmes e séries organizados.
  const detected = detectXtreamFromM3U(url);
  if (detected) {
    onStatus("Link com usuário e senha encontrado. Conectando ao servidor…");
    try {
      await getAccountInfo(detected);
      await saveXtream(id, typedName || "Minha lista", detected, now);
      return;
    } catch { /* não respondeu como Xtream: segue como lista M3U comum */ }
  }

  onStatus("Verificando a lista M3U…");
  let response: Response;
  try { response = await fetch(url); }
  catch { throw new Error("Não foi possível acessar o endereço do link. Confira se ele está correto e se você está com internet."); }
  if (!response.ok) throw new Error("Não foi possível acessar a lista (HTTP " + response.status + ").");
  inspectM3UText(await response.text());
  const item: SavedPlaylist = { id, name: typedName || "Minha lista", kind: "m3u", playlistUrl: url, addedAt: now, lastUpdatedAt: now };
  await addAndActivatePlaylist(item);
}
