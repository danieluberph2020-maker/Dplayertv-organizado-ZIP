import { parseM3U } from "../parsers/m3u";
import type { XtreamCredentials } from "../types/media";

export function validateXtream(serverUrl: string, username: string, password: string): XtreamCredentials {
  let parsed: URL;
  try { parsed = new URL(serverUrl.trim()); } catch { throw new Error("Informe o endereço completo do servidor, incluindo http:// ou https://."); }
  if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("O servidor precisa usar HTTP ou HTTPS.");
  if (!username.trim() || !password) throw new Error("Informe usuário e senha.");
  return { serverUrl: parsed.origin + parsed.pathname.replace(/\/$/, ""), username: username.trim(), password };
}
export function validateM3UUrl(value: string): string {
  let parsed: URL;
  try { parsed = new URL(value.trim()); } catch { throw new Error("Cole um endereço M3U/M3U8 válido."); }
  if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("A lista precisa usar um endereço HTTP ou HTTPS.");
  return parsed.toString();
}
export function inspectM3UText(text: string) {
  if (!text.trimStart().startsWith("#EXTM3U")) throw new Error("O arquivo não parece ser uma lista M3U válida.");
  const result = parseM3U(text);
  if (!result.items.length) throw new Error("A lista não contém entradas reconhecidas.");
  return result;
}
