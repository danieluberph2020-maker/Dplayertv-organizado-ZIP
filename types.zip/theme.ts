export const colors = {
  background: "#05070B",
  surface: "#0D121B",
  surfaceRaised: "#121A26",
  border: "#1C2736",
  blue: "#328BFF",
  blueSoft: "#102B4B",
  text: "#F5F7FA",
  muted: "#8B96A8",
  danger: "#F06464",
  success: "#39C98A",
} as const;
