import type { MediaItem, PlaylistParseResult } from "../types/media";

function attr(line: string, name: string): string | undefined {
  const match = line.match(new RegExp(name + '="([^"]*)"', "i"));
  return match?.[1]?.trim() || undefined;
}
function clean(value: string): string {
  return value.replace(/&amp;/g, "&").replace(/&#39;/g, "'").trim();
}
function kindOf(url: string): MediaItem["kind"] {
  if (/\/movie\//i.test(url)) return "movie";
  if (/\/series\//i.test(url)) return "series";
  return "live";
}
export function parseM3U(source: string): PlaylistParseResult {
  const lines = source.replace(/^\uFEFF/, "").split(/\r?\n/);
  const items: MediaItem[] = [];
  let pending: Omit<MediaItem, "url"> | null = null;
  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith("#EXTINF")) {
      const comma = line.lastIndexOf(",");
      const title = comma >= 0 ? clean(line.slice(comma + 1)) : "Sem título";
      const group = clean(attr(line, "group-title") || "Outros");
      pending = {
        id: String(items.length), title, group,
        logo: attr(line, "tvg-logo"), epgId: attr(line, "tvg-id"),
        kind: "live"
      };
      continue;
    }
    if (line.startsWith("#")) continue;
    if (pending && /^(https?|rtmp|rtsp):\/\//i.test(line)) {
      items.push({ ...pending, url: line, kind: kindOf(line) });
      pending = null;
    }
  }
  const groups = [...new Set(items.map(item => item.group))].sort((a,b)=>a.localeCompare(b));
  return { items, groups };
}
export function detectXtreamFromM3U(input: string): { serverUrl: string; username: string; password: string } | null {
  try {
    const url = new URL(input.trim());
    const username = url.searchParams.get("username");
    const password = url.searchParams.get("password");
    if (!username || !password) return null;
    const serverUrl = url.origin;
    return { serverUrl, username, password };
  } catch { return null; }
}