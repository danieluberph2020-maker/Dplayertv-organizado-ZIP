import * as FileSystem from "expo-file-system/legacy";
import type { Catalog } from "../types/media";

// O catálogo de uma lista IPTV pode ter dezenas de MB. O AsyncStorage do Android tem limite
// de ~6 MB (erro SQLITE_FULL), por isso o cache fica em arquivo.
function cachePath(playlistId: string): string | null {
  const dir = FileSystem.documentDirectory || FileSystem.cacheDirectory;
  if (!dir) return null;
  return dir + "dplayertv-catalog-v2-" + playlistId.replace(/[^a-zA-Z0-9_-]/g, "_") + ".json";
}

/** Falhas ao gravar o cache são ignoradas: o catálogo já foi carregado e deve aparecer. */
export async function cacheCatalog(playlistId: string, catalog: Catalog): Promise<void> {
  const path = cachePath(playlistId);
  if (!path) return;
  try { await FileSystem.writeAsStringAsync(path, JSON.stringify(catalog)); } catch { /* sem cache, segue normal */ }
}
export async function getCachedCatalog(playlistId: string): Promise<Catalog | null> {
  const path = cachePath(playlistId);
  if (!path) return null;
  try {
    const info = await FileSystem.getInfoAsync(path);
    if (!info.exists) return null;
    return JSON.parse(await FileSystem.readAsStringAsync(path)) as Catalog;
  } catch { return null; }
}
export async function removeCachedCatalog(playlistId: string): Promise<void> {
  const path = cachePath(playlistId);
  if (!path) return;
  try { await FileSystem.deleteAsync(path, { idempotent: true }); } catch { /* ignora */ }
}
