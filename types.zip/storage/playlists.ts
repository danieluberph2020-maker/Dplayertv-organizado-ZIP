import AsyncStorage from "@react-native-async-storage/async-storage";
import * as SecureStore from "expo-secure-store";
import type { SavedPlaylist } from "../types/media";

const PLAYLISTS_KEY = "dplayertv.playlists.v1";
const ACTIVE_KEY = "dplayertv.activePlaylist.v1";
const SECRET_PREFIX = "dplayertv.secret.";

export function createPlaylistId() {
  return "list-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
}

export async function getPlaylists(): Promise<SavedPlaylist[]> {
  const raw = await AsyncStorage.getItem(PLAYLISTS_KEY);
  if (!raw) return [];
  try { return JSON.parse(raw) as SavedPlaylist[]; } catch { return []; }
}
export async function getActivePlaylistId(): Promise<string | null> {
  return AsyncStorage.getItem(ACTIVE_KEY);
}
/** Lista atualmente ativa (ou null). Substitui o trecho repetido nas telas. */
export async function getActivePlaylist(): Promise<SavedPlaylist | null> {
  const [id, lists] = await Promise.all([getActivePlaylistId(), getPlaylists()]);
  return lists.find(x => x.id === id) ?? null;
}
export async function savePlaylist(playlist: SavedPlaylist, password?: string): Promise<void> {
  const playlists = await getPlaylists();
  await AsyncStorage.setItem(PLAYLISTS_KEY, JSON.stringify([...playlists.filter(item => item.id !== playlist.id), playlist]));
  if (password) await SecureStore.setItemAsync(SECRET_PREFIX + playlist.id, password);
}
export async function setActivePlaylist(id: string): Promise<void> {
  await AsyncStorage.setItem(ACTIVE_KEY, id);
}
export async function addAndActivatePlaylist(item: SavedPlaylist, password?: string) {
  await savePlaylist(item, password);
  await setActivePlaylist(item.id);
}
export async function getXtreamPassword(id: string): Promise<string | null> {
  return SecureStore.getItemAsync(SECRET_PREFIX + id);
}
export async function removePlaylist(id: string): Promise<void> {
  const playlists = (await getPlaylists()).filter(item => item.id !== id);
  await AsyncStorage.setItem(PLAYLISTS_KEY, JSON.stringify(playlists));
  await SecureStore.deleteItemAsync(SECRET_PREFIX + id);
  if (await getActivePlaylistId() === id) {
    if (playlists[0]) await setActivePlaylist(playlists[0].id);
    else await AsyncStorage.removeItem(ACTIVE_KEY);
  }
}
