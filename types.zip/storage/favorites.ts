import AsyncStorage from "@react-native-async-storage/async-storage";
const KEY = "dplayertv.favorites.v1";
export type FavoriteEntry = { playlistId: string; section: "live" | "movie" | "series"; mediaId: string };
async function read(): Promise<FavoriteEntry[]> {
  const raw = await AsyncStorage.getItem(KEY);
  if (!raw) return [];
  try { return JSON.parse(raw) as FavoriteEntry[]; } catch { return []; }
}
export async function isFavorite(playlistId: string, section: FavoriteEntry["section"], mediaId: string) {
  return (await read()).some(x => x.playlistId === playlistId && x.section === section && x.mediaId === mediaId);
}
export async function toggleFavorite(entry: FavoriteEntry) {
  const all = await read();
  const exists = all.some(x => x.playlistId === entry.playlistId && x.section === entry.section && x.mediaId === entry.mediaId);
  const next = exists ? all.filter(x => !(x.playlistId === entry.playlistId && x.section === entry.section && x.mediaId === entry.mediaId)) : [...all, entry];
  await AsyncStorage.setItem(KEY, JSON.stringify(next));
  return !exists;
}
export async function getFavoriteIds(playlistId: string, section: FavoriteEntry["section"]) {
  return (await read()).filter(x => x.playlistId === playlistId && x.section === section).map(x => x.mediaId);
}