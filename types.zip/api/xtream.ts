import type { MediaItem, XtreamCredentials, SeriesDetails, SeriesEpisode } from "../types/media";

type AccountInfo = { user_info?: { username?: string; status?: string; exp_date?: string | null; is_trial?: string; active_cons?: string; max_connections?: string } };
type XtreamCategory = { category_id: string | number; category_name: string };
type XtreamStream = { stream_id?: number; series_id?: number; name: string; stream_icon?: string; category_id?: string | number; container_extension?: string; plot?: string; cover?: string; year?: string; rating?: string };
type SeriesInfoResponse = { info?: { name?: string; cover?: string; plot?: string }; episodes?: Record<string, Array<{ id: number | string; title?: string; episode_num?: number; container_extension?: string; info?: { plot?: string } }>> };
export type XtreamConnection = { account: AccountInfo; live: MediaItem[]; movies: MediaItem[]; series: MediaItem[]; categories: { live: XtreamCategory[]; movies: XtreamCategory[]; series: XtreamCategory[] } };

function normalizeServer(value: string): string {
  const trimmed = value.trim().replace(/\/+$/, "");
  const parsed = new URL(trimmed);
  if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("Use um endereço HTTP ou HTTPS válido.");
  return parsed.origin + (parsed.pathname === "/" ? "" : parsed.pathname);
}
function hostOf(url: string): string {
  return url.replace(/^https?:\/\//i, "").split(/[/?]/)[0];
}
async function request<T>(url: string): Promise<T> {
  let response: Response;
  try { response = await fetch(url); }
  catch { throw new Error("Não foi possível conectar ao servidor " + hostOf(url) + ". Verifique o endereço e sua conexão."); }
  if (!response.ok) throw new Error("O servidor " + hostOf(url) + " respondeu com erro (" + response.status + ").");
  try { return (await response.json()) as T; }
  catch { throw new Error("O servidor " + hostOf(url) + " não devolveu uma resposta Xtream válida. Confira usuário, senha e endereço."); }
}
function apiBase(input: XtreamCredentials) {
  return normalizeServer(input.serverUrl) + "/player_api.php?username=" + encodeURIComponent(input.username.trim()) + "&password=" + encodeURIComponent(input.password);
}
export async function getSeriesDetails(input: XtreamCredentials, seriesId: string): Promise<SeriesDetails> {
  const base = apiBase(input);
  const data = await request<SeriesInfoResponse>(base + "&action=get_series_info&series_id=" + encodeURIComponent(seriesId));
  const server = normalizeServer(input.serverUrl);
  const seasons = Object.entries(data.episodes || {}).map(([season, episodes]) => ({
    season,
    episodes: episodes.map((ep): SeriesEpisode => ({
      id: String(ep.id), title: ep.title || "Episódio " + (ep.episode_num ?? ""),
      season, episode: String(ep.episode_num ?? ""), extension: ep.container_extension,
      plot: ep.info?.plot,
      url: server + "/series/" + encodeURIComponent(input.username.trim()) + "/" + encodeURIComponent(input.password) + "/" + ep.id + (ep.container_extension ? "." + ep.container_extension : "")
    }))
  }));
  return { title: data.info?.name || "Série", poster: data.info?.cover, plot: data.info?.plot, seasons };
}
/** Consulta só os dados da conta (leve). Não baixa o catálogo. */
export async function getAccountInfo(input: XtreamCredentials): Promise<AccountInfo> {
  const account = await request<AccountInfo>(apiBase(input));
  if (!account?.user_info) throw new Error("Resposta inválida do servidor. Confira os dados de acesso.");
  const status = account.user_info.status?.toLowerCase();
  if (status && !["active", "enabled"].includes(status)) throw new Error("A conta do provedor não está ativa: " + status);
  return account;
}
export async function connectXtream(input: XtreamCredentials): Promise<XtreamConnection> {
  const base = apiBase(input);
  const account = await getAccountInfo(input);
  const server = normalizeServer(input.serverUrl);
  const [liveCats, movieCats, seriesCats, live, movies, series] = await Promise.all([
    request<XtreamCategory[]>(base + "&action=get_live_categories"),
    request<XtreamCategory[]>(base + "&action=get_vod_categories"),
    request<XtreamCategory[]>(base + "&action=get_series_categories"),
    request<XtreamStream[]>(base + "&action=get_live_streams"),
    request<XtreamStream[]>(base + "&action=get_vod_streams"),
    request<XtreamStream[]>(base + "&action=get_series")
  ]);
  const categoryNames = (cats: XtreamCategory[]) => new Map((cats || []).map(c => [String(c.category_id), c.category_name]));
  const groupOf = (names: Map<string, string>, id: string | number | undefined) => (id === undefined ? undefined : names.get(String(id))) || "Outros";
  const liveNames = categoryNames(liveCats), movieNames = categoryNames(movieCats), seriesNames = categoryNames(seriesCats);
  const map = (rows: XtreamStream[], kind: "live" | "movie"): MediaItem[] =>
    rows.map(row => ({
      id: String(row.stream_id), title: row.name || "Sem título",
      url: server + (kind === "live" ? "/live/" : "/movie/") + encodeURIComponent(input.username.trim()) + "/" + encodeURIComponent(input.password) + "/" + row.stream_id + (row.container_extension ? "." + row.container_extension : ""),
      group: groupOf(kind === "live" ? liveNames : movieNames, row.category_id), logo: row.stream_icon, poster: row.cover,
      description: row.plot, kind, containerExtension: row.container_extension, year: row.year, rating: row.rating
    }));
  const seriesItems: MediaItem[] = (series || []).map(row => ({
    id: String(row.series_id), title: row.name || "Sem título", url: "",
    group: groupOf(seriesNames, row.category_id), poster: row.cover || row.stream_icon,
    description: row.plot, kind: "series", isSeriesContainer: true, year: row.year, rating: row.rating
  }));
  return {
    account, categories: { live: liveCats || [], movies: movieCats || [], series: seriesCats || [] },
    live: map(live || [], "live"), movies: map(movies || [], "movie"), series: seriesItems
  };
}